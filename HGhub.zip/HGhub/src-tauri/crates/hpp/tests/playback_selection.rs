use hghub_hpp::{ipc, model, PluginManager};
use serde_json::{json, Value};
use std::sync::Arc;

#[tokio::test]
async fn source_and_resolver_choices_route_to_their_own_stage_without_exposing_resources() {
    let dir = tempfile::tempdir().unwrap();
    let manager = Arc::new(PluginManager::with_mode(dir.path().into(), Some(false)).unwrap());
    let source = r#"
      export const meta={id:'fixture.choices',name:'虚构选择源',version:'1.0.0',protocol:1};
      export default hg=>({media:{getDetail({id}){return {id,title:id,playlists:[{id:'main',episodes:[]}]};},
        async resolvePlayback(p){
          await hg.storage.set('last',p);
          if(p.serverId&&p.serverId!=='source-b')throw new Error('resolver server leaked to source');
          const serverId=p.serverId||'source-a';
          return {servers:[{id:'source-a',label:'源 A',secret:'discard'},{id:'source-b',label:'源 B'}],
            streams:[{url:'https://media.example/direct.mp4',format:'progressive',serverId,label:'直接播放',headers:{Authorization:'secret'}},
              {url:'https://page.example/watch',kind:'page',serverId,label:'播放页',resolverId:'fixture.choice.resolver'}],
            durationSec:100,expiresAt:9000000000000};
      }}});
    "#;
    let resolver = r#"
      export const meta={id:'fixture.choice.resolver',name:'虚构选择解析器',version:'1.0.0',protocol:1,kind:'resolver',matches:['page.example']};
      export default hg=>({resolver:{async resolve(p){
        await hg.storage.set('last',p);
        if(p.serverId&&p.serverId!=='resolver-b')throw new Error('source server leaked to resolver');
        const serverId=p.serverId||'resolver-a';
        return {servers:[{id:'resolver-a',label:'解析 A'},{id:'resolver-b',label:'解析 B'}],
          streams:[{url:'https://media.example/a.mp4',format:'progressive',label:'720p',height:720,serverId},
            {url:'https://media.example/b.mp4',format:'progressive',label:'1080p',height:1080,serverId,headers:{Cookie:'secret'}}],
          durationSec:120,expiresAt:8000000000000};
      }}});
    "#;
    for code in [source, resolver] {
        assert_eq!(
            manager
                .import_code(code.into(), None, false)
                .await
                .unwrap()
                .status,
            "ready"
        );
    }
    let params = json!({"id":"fixture.choices","requestId":"select", "streamIndex":1,
        "resolverId":"unavailable.preference", "resolverStreamIndex":1,
        "resolverServers":{"fixture.choice.resolver":"resolver-b","unrelated.resolver":"wrong"},
        "args":{"mediaId":"one","episodeId":"ep","serverId":"source-b","reason":"refresh","codecs":["h264"],"maxHeight":1080}});
    let prepared = ipc::dispatch(&manager, "media.prepare".into(), params)
        .await
        .unwrap();
    assert_eq!(prepared["providerId"], "fixture.choice.resolver");
    assert_eq!(prepared["choices"]["source"]["streamIndex"], 1);
    assert_eq!(prepared["choices"]["source"]["serverId"], "source-b");
    assert_eq!(prepared["choices"]["resolver"]["streamIndex"], 1);
    assert_eq!(prepared["choices"]["resolver"]["serverId"], "resolver-b");
    assert_eq!(
        prepared["choices"]["source"]["streams"]
            .as_array()
            .unwrap()
            .len(),
        2
    );
    assert_eq!(prepared["playback"]["durationSec"], 120);
    assert_eq!(prepared["playback"]["expiresAt"], 8000000000000u64);
    let visible = prepared.to_string();
    for hidden in [
        "secret",
        "Authorization",
        "Cookie",
        "https://page.example/watch",
        "media.example",
    ] {
        assert!(!visible.contains(hidden), "{hidden} leaked");
    }
    // The second source stream is pinned to this resolver, so a stale saved preference cannot override it.
    for (id, stage_server) in [
        ("fixture.choices", "source-b"),
        ("fixture.choice.resolver", "resolver-b"),
    ] {
        let saved: Value = serde_json::from_slice(
            &std::fs::read(dir.path().join(id).join("storage.json")).unwrap(),
        )
        .unwrap();
        assert!(saved.to_string().contains(stage_server));
        assert!(!saved.to_string().contains(if id == "fixture.choices" {
            "resolver-b"
        } else {
            "source-b"
        }));
    }
    manager
        .sessions
        .release(prepared["sessionId"].as_str().unwrap());
    // Defaults have no serverId argument; in particular they must not contain null as a string option.
    let default = manager
        .prepare_media(
            "fixture.choices",
            json!({"mediaId":"one","episodeId":"ep","reason":"play","codecs":["h264"]}),
            1,
            None,
            "default".into(),
        )
        .await
        .unwrap();
    assert_eq!(default.choices["resolver"]["serverId"], "resolver-a");
    manager.sessions.release(&default.session_id);
    manager
        .set_enabled("fixture.choice.resolver", false)
        .await
        .unwrap();
    let unavailable = manager
        .prepare_media(
            "fixture.choices",
            json!({"mediaId":"one","episodeId":"ep","reason":"play","codecs":["h264"]}),
            1,
            None,
            "unavailable".into(),
        )
        .await
        .err()
        .unwrap();
    assert_eq!(unavailable.code, "UNSUPPORTED");
    assert_eq!(
        unavailable.playback_choices.unwrap()["source"]["streams"]
            .as_array()
            .unwrap()
            .len(),
        2
    );
    let spoofed: hghub_hpp::PluginError = serde_json::from_value(
        json!({"code":"AUTH_REQUIRED","message":"test","playbackChoices":{"source":"spoof"}}),
    )
    .unwrap();
    assert!(spoofed.playback_choices.is_none());
    for invalid in [json!(-1), json!("1"), json!(16)] {
        let error = ipc::dispatch(
            &manager,
            "media.prepare".into(),
            json!({"id":"fixture.choices","requestId":"invalid","streamIndex":invalid}),
        )
        .await
        .err()
        .unwrap();
        assert_eq!(error.code, "INVALID_ARGUMENT");
    }
}

#[test]
fn playback_option_validation_discards_bad_rows_and_strips_unknown_fields() {
    let result=model::validate_result("media.resolvePlayback",json!({
        "streams":[{"url":"https://media.example/a","format":"progressive","label":{"bad":true}},
          {"url":"https://media.example/b","format":"progressive","height":1080,"codec":"h264","label":"高清"}],
        "servers":[{"id":"a","label":"主线","secret":"discard"},{"id":"a","label":"重复"},{"id":2}],
    }),false).unwrap();
    assert_eq!(result["streams"].as_array().unwrap().len(), 1);
    assert_eq!(result["servers"], json!([{"id":"a","label":"主线"}]));
}
