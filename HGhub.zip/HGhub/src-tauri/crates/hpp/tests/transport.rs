use axum::{
    body::Body,
    extract::State,
    http::{HeaderMap, Method, Response, Uri},
    routing::any,
    Router,
};
use hghub_hpp::PluginManager;
use serde_json::{json, Value};
use std::{
    sync::{Arc, Mutex},
    time::Duration,
};
const SOURCE: &str = include_str!("fixtures/synthetic.js");
type Requests = Arc<Mutex<Vec<(String, HeaderMap)>>>;

async fn fixture(
    State(seen): State<Requests>,
    method: Method,
    uri: Uri,
    headers: HeaderMap,
) -> Response<Body> {
    seen.lock()
        .unwrap()
        .push((uri.to_string(), headers.clone()));
    let mut out = Response::builder();
    let body=match uri.path(){
        "/cookie"=>{out=out.header("set-cookie","login=fixture; Path=/; HttpOnly").header("content-type","application/json");json!({"cookie":headers.get("cookie").and_then(|v|v.to_str().ok()).unwrap_or("")}).to_string()},
        "/slow"=>{tokio::time::sleep(Duration::from_millis(300)).await;"slow".into()},
        "/start"=>return out.status(302).header("location","/hls/master.m3u8?signature=master").body(Body::empty()).unwrap(),
        "/hls/master.m3u8"=>"#EXTM3U\n#EXT-X-MEDIA:TYPE=AUDIO,GROUP-ID=\"a\",URI=\"audio.m3u8?audio=1\"\n#EXT-X-STREAM-INF:BANDWIDTH=100000,AUDIO=\"a\"\nvariant.m3u8?variant=2\n".into(),
        "/hls/variant.m3u8"|"/hls/audio.m3u8"=>"#EXTM3U\n#EXT-X-TARGETDURATION:10\n#EXT-X-KEY:METHOD=AES-128,URI=\"key.bin?key=3\"\n#EXT-X-MAP:URI=\"init.mp4?init=4\"\n#EXTINF:1,\nsegment.ts?segment=5\n#EXT-X-ENDLIST\n".into(),
        "/movie.mp4"=>{
            let bytes="0123456789";
            if let Some(range)=headers.get("range").and_then(|v|v.to_str().ok()){
                if range=="bytes=2-5"{out=out.status(206).header("content-range","bytes 2-5/10").header("content-length","4");"2345".into()}
                else{return out.status(416).header("content-range","bytes */10").body(Body::empty()).unwrap();}
            }else{out=out.header("content-length",bytes.len());bytes.into()}
        },
        "/image"=>"fixture-image".into(),
        _=>"fixture-resource".into()
    };
    out.body(if method == Method::HEAD {
        Body::empty()
    } else {
        Body::from(body)
    })
    .unwrap()
}
async fn server() -> (String, Requests, tokio::task::JoinHandle<()>) {
    let seen: Requests = Default::default();
    let listener = tokio::net::TcpListener::bind("127.0.0.1:0").await.unwrap();
    let base = format!("http://{}", listener.local_addr().unwrap());
    let router = Router::new()
        .route("/*path", any(fixture))
        .with_state(seen.clone());
    let task = tokio::spawn(async move {
        axum::serve(listener, router).await.unwrap();
    });
    (base, seen, task)
}
fn manager(dir: &tempfile::TempDir) -> Arc<PluginManager> {
    Arc::new(PluginManager::with_mode(dir.path().into(), Some(false)).unwrap())
}
fn params() -> Value {
    json!({"mediaId":"one","episodeId":"ep1","playlistId":"main","reason":"play","codecs":["h264"]})
}
fn http_source(base: &str) -> String {
    SOURCE.replace("if(query===\"spin\")",&format!(r#"
        if(query==="http"||query==="http-once") {{
          const a=await hg.http.fetch({{url:"{base}/cookie",responseType:"json"}});
          query=a.data.cookie||"<empty>";
        }}
        if(query==="http-cancel") {{await hg.http.fetch({{url:"{base}/slow"}});await hg.storage.set("late-write",true);}}
        if(query==="spin")"#))
}

#[tokio::test]
async fn http_cookies_scope_and_implicit_cancellation() {
    let (base, seen, task) = server().await;
    let dir = tempfile::tempdir().unwrap();
    let m = manager(&dir);
    m.import_code(http_source(&base), None, false)
        .await
        .unwrap();
    m.import_code(
        http_source(&base).replace("fixture.source", "fixture.other"),
        None,
        false,
    )
    .await
    .unwrap();
    for (id, expected) in [
        ("fixture.source", "<empty>"),
        ("fixture.source", "login=fixture"),
        ("fixture.other", "<empty>"),
    ] {
        let v = m
            .call(
                id,
                "search.search",
                json!({"query":"http"}),
                uuid::Uuid::new_v4().to_string(),
            )
            .await
            .unwrap();
        assert_eq!(v["items"][0]["title"], expected);
    }
    let copy = m.clone();
    let pending = tokio::spawn(async move {
        copy.call(
            "fixture.source",
            "search.search",
            json!({"query":"http-cancel"}),
            "cancel-http".into(),
        )
        .await
    });
    tokio::time::timeout(Duration::from_secs(3), async {
        loop {
            if seen.lock().unwrap().iter().any(|(u, _)| u == "/slow") {
                break;
            }
            tokio::time::sleep(Duration::from_millis(5)).await;
        }
    })
    .await
    .unwrap();
    m.cancel("cancel-http").await;
    assert_eq!(pending.await.unwrap().unwrap_err().code, "CANCELLED");
    tokio::time::sleep(Duration::from_millis(350)).await;
    let result = m
        .call(
            "fixture.source",
            "search.search",
            json!({"query":"late-check"}),
            "check".into(),
        )
        .await
        .unwrap();
    assert_eq!(result["items"][0]["title"], "undefined");
    task.abort();
}
#[tokio::test]
async fn shared_promises_and_completed_calls_do_not_leak_scope() {
    let dir = tempfile::tempdir().unwrap();
    let m = manager(&dir);
    m.import_code(SOURCE.into(), None, false).await.unwrap();
    let (a, b) = tokio::join!(
        m.call(
            "fixture.source",
            "search.search",
            json!({"query":"shared"}),
            "shared-a".into()
        ),
        m.call(
            "fixture.source",
            "search.search",
            json!({"query":"shared"}),
            "shared-b".into()
        )
    );
    assert_eq!(a.unwrap()["items"][0]["title"], "shared-a");
    assert_eq!(b.unwrap()["items"][0]["title"], "shared-b");
    m.call(
        "fixture.source",
        "search.search",
        json!({"query":"late"}),
        "late".into(),
    )
    .await
    .unwrap();
    tokio::time::sleep(Duration::from_millis(150)).await;
    assert_eq!(
        m.call(
            "fixture.source",
            "search.search",
            json!({"query":"late-check"}),
            "check".into()
        )
        .await
        .unwrap()["items"][0]["title"],
        "undefined"
    );
}
#[tokio::test]
async fn progressive_range_head_and_release() {
    let (base, _seen, task) = server().await;
    let dir = tempfile::tempdir().unwrap();
    let m = manager(&dir);
    m.import_code(
        SOURCE.replace(
            "https://media.example/movie.mp4",
            &format!("{base}/movie.mp4"),
        ),
        None,
        false,
    )
    .await
    .unwrap();
    let media = m
        .prepare_media("fixture.source", params(), 0, None, "prepare".into())
        .await
        .unwrap();
    let client = reqwest::Client::new();
    let response = client
        .get(&media.url)
        .header("range", "bytes=2-5")
        .send()
        .await
        .unwrap();
    assert_eq!(response.status(), 206);
    assert_eq!(response.headers()["content-range"], "bytes 2-5/10");
    assert_eq!(response.text().await.unwrap(), "2345");
    let head = client.head(&media.url).send().await.unwrap();
    assert_eq!(head.status(), 200);
    assert_eq!(head.headers()["content-length"], "10");
    assert!(head.bytes().await.unwrap().is_empty());
    assert_eq!(
        client
            .get(&media.url)
            .header("range", "bytes=30-40")
            .send()
            .await
            .unwrap()
            .status(),
        416
    );
    m.sessions.release(&media.session_id);
    assert_eq!(client.get(&media.url).send().await.unwrap().status(), 404);
    task.abort();
}
#[tokio::test]
async fn hls_redirect_master_keys_maps_and_queries() {
    let (base, seen, task) = server().await;
    let dir = tempfile::tempdir().unwrap();
    let m = manager(&dir);
    let source = SOURCE
        .replace("https://media.example/movie.mp4", &format!("{base}/start"))
        .replace("format:\"progressive\"", "format:\"hls\"");
    m.import_code(source, None, false).await.unwrap();
    let media = m
        .prepare_media("fixture.source", params(), 0, None, "prepare".into())
        .await
        .unwrap();
    let client = reqwest::Client::new();
    let master = client
        .get(&media.url)
        .send()
        .await
        .unwrap()
        .text()
        .await
        .unwrap();
    assert!(master.contains("#EXT-X-STREAM-INF"));
    assert!(!master.contains("signature="));
    let variant = master.lines().find(|s| s.starts_with("http")).unwrap();
    let playlist = client
        .get(variant)
        .send()
        .await
        .unwrap()
        .text()
        .await
        .unwrap();
    let uris = regex::Regex::new(r#"URI="([^"]+)""#).unwrap();
    for capture in uris.captures_iter(&playlist) {
        let r = client.get(&capture[1]).send().await.unwrap();
        assert_eq!(r.status(), 200);
    }
    let segment = playlist.lines().find(|s| s.starts_with("http")).unwrap();
    assert_eq!(client.get(segment).send().await.unwrap().status(), 200);
    let requests = seen.lock().unwrap();
    for url in [
        "/hls/variant.m3u8?variant=2",
        "/hls/key.bin?key=3",
        "/hls/init.mp4?init=4",
        "/hls/segment.ts?segment=5",
    ] {
        assert!(
            requests.iter().any(|(u, _)| u == url),
            "missing {url}: {requests:?}"
        );
    }
    task.abort();
}
#[tokio::test]
async fn endpoint_initialization_and_settings_revoke_media() {
    let (base, _, task) = server().await;
    let dir = tempfile::tempdir().unwrap();
    let m = manager(&dir);
    let source=SOURCE.replace("return {\n    media:",&format!(r#"return {{
      endpoints:{{async list(){{if(hg.endpoint.current===null)await hg.storage.set("initial-null",true);return [{{id:"a",url:"{base}"}},{{id:"b",url:"http://localhost:12345"}}];}}}},
      media:"#)).replace("title:hg.settings.get(\"label\")","title:hg.endpoint.url('/movie.mp4')").replace("https://media.example/movie.mp4",&format!("{base}/movie.mp4"));
    let info = m.import_code(source, None, false).await.unwrap();
    assert_eq!(info.status, "ready", "{:?}", info.error);
    assert_eq!(info.endpoint["id"], "a");
    let detail = m
        .call(
            "fixture.source",
            "media.getDetail",
            json!({"id":"one"}),
            "detail".into(),
        )
        .await
        .unwrap();
    assert_eq!(detail["title"], format!("{base}/movie.mp4"));
    let media = m
        .prepare_media("fixture.source", params(), 0, None, "prepare".into())
        .await
        .unwrap();
    m.settings_set("fixture.source", "label".into(), json!("changed"))
        .await
        .unwrap();
    assert_eq!(reqwest::get(media.url).await.unwrap().status(), 404);
    let info = m.endpoint_set("fixture.source", "b").await.unwrap();
    assert_eq!(info.endpoint["id"], "b");
    task.abort();
}
